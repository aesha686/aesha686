from django.shortcuts import render
from django.http import HttpResponse

# This list will store the names of the students
student_names = []

def index(req):
    return render(req,"student_data.html")

def studentdata(req):
    enrollmentno = req.GET.get("enrollmentno")
    name = req.GET.get("name")
    djangomarks = req.GET.get("djangomarks")
    javamarks = req.GET.get("javamarks")

    if name:
        student_names.append(name)

    dictData = {
        "enrollmentno": enrollmentno,
        "name": name,
        "djangomarks": djangomarks,
        "javamarks": javamarks,
        "total_students": len(student_names)
    }

    return render(req, "showdata.html", dictData)
